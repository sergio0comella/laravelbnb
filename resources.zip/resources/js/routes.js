import VueRouter from "vue-router";
import BookablesListItem from "./bookables/BookableListItem";
import Bookables from './bookables/Bookables';

const routes = [
    {
        path: "/",
        component: Bookables,
        name: "home",
    },
    {
        path: "/second",
        component: BookablesListItem,
        name: "second",
    },
];

const router = new VueRouter({
    mode: 'history',
    routes // short for `routes: routes`
});

export default router;
